-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 26, 2023 at 04:48 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `organisasi`
--

-- --------------------------------------------------------

--
-- Table structure for table `dataorg`
--

CREATE TABLE `dataorg` (
  `id` int(11) NOT NULL,
  `nama` varchar(256) NOT NULL,
  `nim` int(11) NOT NULL,
  `jabatan` varchar(50) DEFAULT NULL,
  `nama_himpunan` varchar(255) NOT NULL,
  `usia` int(11) NOT NULL,
  `created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dataorg`
--

INSERT INTO `dataorg` (`id`, `nama`, `nim`, `jabatan`, `nama_himpunan`, `usia`, `created`) VALUES
(1, 'Andi', 70202104, 'Ketua', 'Himpunan Mahasiswa Sistem Informasi', 20, '2023-06-26 16:42:34'),
(2, 'Budi', 70202105, 'Wakil Ketua', 'Himpunan Mahasiswa Sistem Informasi', 21, '2023-06-26 16:42:40'),
(3, 'Cici', 70202106, 'Sekretaris', 'Himpunan Mahasiswa Sistem Informasi', 22, '2023-06-26 16:42:46'),
(4, 'Dodi', 70202107, 'Bendahara', 'Himpunan Mahasiswa Sistem Informasi', 23, '2023-06-26 16:42:51'),
(5, 'Eka', 70202108, 'Koor Kominfo', 'Himpunan Mahasiswa Sistem Informasi', 24, '2023-06-26 16:42:56'),
(6, 'Fani', 70202109, 'Angg Kominfo', 'Himpunan Mahasiswa Sistem Informasi', 25, '2023-06-26 16:43:03'),
(7, 'Gita', 70202110, 'Angg Kominfo', 'Himpunan Mahasiswa Sistem Informasi', 26, '2023-06-26 16:43:08'),
(8, 'Hadi', 70202111, 'Angg Kominfo', 'Himpunan Mahasiswa Sistem Informasi', 27, '2023-06-26 16:43:15'),
(9, 'Ika', 70202112, 'Angg Kominfo', 'Himpunan Mahasiswa Sistem Informasi', 28, '2023-06-26 16:43:19'),
(19, 'ANI CAHYANI', 70202103, 'Wakil', 'Sipil', 21, '2023-06-26 16:27:58');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dataorg`
--
ALTER TABLE `dataorg`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dataorg`
--
ALTER TABLE `dataorg`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
